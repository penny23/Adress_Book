import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingPageComponent } from './components/routes/home/home.component';
import { CreateContactComponent } from './components/routes/create-contact/create.component';
import { ContactDetailsComponent } from './components/routes/contact-details/contact-details.component';

const routes: Routes = [
  {
    path: '',
    component: LandingPageComponent
},

{
  path: 'create-contact',
  component: CreateContactComponent
},
{
  path: 'contact-details/id',
  component: ContactDetailsComponent
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
