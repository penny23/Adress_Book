import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Contact } from '../models/contact';


@Injectable({
    providedIn: 'root',
})
export class ContactService {

    private readonly url: string;

    constructor(private httpClient: HttpClient) {
        this.url = `${environment.apiUrl}/Contact`;
    }

    createContact(contact: Contact): Observable<Contact> {
       return this.httpClient.post<Contact>(this.url, contact);
    }

    getAllContacts(): Observable<Contact[]> {
        const getUrl = `${this.url}/GetAllContacts`;

        return this.httpClient.get<Contact[]>(getUrl);
    }

    updateContact(contact: Contact): Observable<Contact> {
        return this.httpClient.post<Contact>(this.url, contact);
     }
    getContact(id: number): Observable<Contact> {

        return this.httpClient.get<Contact>(`${this.url}/GetContact/${id}`);
    }
}
