import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Contact } from '../models/contact';
import { ContactDetail } from '../models/contact-details';


@Injectable({
    providedIn: 'root',
})
export class ContactDetailService {

    private readonly url: string;

    constructor(private httpClient: HttpClient) {
        this.url = `${environment.apiUrl}/ContactDetail`;
    }

    createContactDetails(contact: ContactDetail): Observable<ContactDetail> {
       return this.httpClient.post<ContactDetail>(this.url, contact);
    }



    updateContactDetail(contact: ContactDetail): Observable<ContactDetail> {
        return this.httpClient.post<ContactDetail>(this.url, contact);
     }

    getContactDetail(id: number): Observable<Contact> {

        return this.httpClient.get<Contact>(`${this.url}/GetContactDetail/${id}`);
    }
}
