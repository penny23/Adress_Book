import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Contact } from '../models/contact';
import { ContactType } from '../models/contact-type';


@Injectable({
    providedIn: 'root',
})
export class ContactTypeService {

    private readonly url: string;

    constructor(private httpClient: HttpClient) {
        this.url = `${environment.apiUrl}/ContactType`;
    }



    getAllContactTypes(): Observable<ContactType[]> {
        const getUrl = `${this.url}/GetAllContactTypes`;

        return this.httpClient.get<ContactType[]>(getUrl);
    }


}
