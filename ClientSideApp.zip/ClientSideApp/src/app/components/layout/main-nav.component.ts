import { Component } from '@angular/core';

@Component({
    selector: 'ec-main-nav',
    templateUrl: './main-nav.component.html',
    styleUrls: ['./main-nav.component.css'],
})
export class MainNavComponent {
}
