import { HttpErrorResponse } from '@angular/common/http';
import { Component, Directive, HostListener, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Meta, Title as pbTitle } from '@angular/platform-browser';
import { Observable, of, Subject } from 'rxjs';

import { ContactTypeService } from 'src/app/service/contact-type.service';
import { ContactType } from 'src/app/models/contact-type';
import { ContactDetailService } from 'src/app/service/contact-details.service';


@Component({
    selector: 'ec-contact-details',
    templateUrl: './contact-details.component.html',
})

export class ContactDetailsComponent implements OnInit{
    isFormSubmitting = false;
    serverError: string;
    isSuccessfull = false;
    contactTypeList: ContactType[];
    private unsubscribe$ = new Subject<void>();

    ContactTypeForm = this.fb.group({
        description: ['', [Validators.required, Validators.maxLength(200)]],
        contactType: ['', [Validators.required]]

    });

    constructor(
        private fb: FormBuilder,
        private contactDetailService: ContactDetailService,
        private contactTypeService: ContactTypeService,
        private router: Router
    ) {
    }

    get contactType() {
        return this.ContactTypeForm.get('contactType');
    }

    get description() {
        return this.ContactTypeForm.get('description');
    }



    ngOnInit() {

        this.contactTypeService.getAllContactTypes().subscribe
            (
                types => {

                    this.contactTypeList = types;

                },
                (error: HttpErrorResponse) => {
                    if (error.status === 400) {
                        this.serverError = error.error;
                    } else if (error.status === 401) {
                        this.serverError = 'We are currently unable to process your request. Please try again later.';
                    } else {
                        this.serverError = 'Oops, we are having a problem. Please try again later.';
                    }
                },
            );

    }

    submitForm() {
        this.ContactTypeForm.markAllAsTouched();

        if (this.ContactTypeForm.invalid || this.isFormSubmitting) {
            return;
        }

        this.isFormSubmitting = true;
        this.serverError = null;

        this.contactDetailService.createContactDetails(this.ContactTypeForm.value).subscribe(
            contactDetails => {

              this.isSuccessfull = true;
            },
            (error: HttpErrorResponse) => {
                if (error.status === 400) {
                    this.serverError = error.error;
                } else if (error.status === 401) {
                    this.serverError = 'We are currently unable to process your request. Please try again later.';
                } else {
                    this.serverError = 'Oops, we are having a problem. Please try again later.';
                }
            },
        );
    }

}
