import { HttpErrorResponse } from '@angular/common/http';
import { Component, Directive, HostListener, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Meta, Title as pbTitle } from '@angular/platform-browser';
import { Observable, of, Subject } from 'rxjs';
import { catchError, filter, finalize, map, switchMap, takeUntil } from 'rxjs/operators';
import { ContactService } from 'src/app/service/contact.service';


@Component({
    selector: 'ec-create-contact',
    templateUrl: './create.component.html',
})

export class CreateContactComponent implements OnInit{
    isFormSubmitting = false;
    serverError: string;
    private unsubscribe$ = new Subject<void>();

    CreateContactForm = this.fb.group({
        firstName: ['', [Validators.required, Validators.maxLength(200)]],
        surname: ['', [Validators.required, Validators.maxLength(200)]],
        contactNumber: ['', [
            Validators.required,
            Validators.minLength(9),
            Validators.maxLength(15),
            Validators.pattern(/^[+\- 0-9]+$/),
        ]],
        birthDate: ['', Validators.required],

    });

    constructor(
        private fb: FormBuilder,
        private contactservice: ContactService,
        private router: Router
    ) {
    }

    get firstName() {
        return this.CreateContactForm.get('firstName');
    }

    get surname() {
        return this.CreateContactForm.get('surname');
    }

    get contactNumber() {
        return this.CreateContactForm.get('contactNumber');
    }

    get birthDate() {
        return this.CreateContactForm.get('birthDate');
    }

    ngOnInit() {


    }

    submitForm() {
        this.CreateContactForm.markAllAsTouched();

        if (this.CreateContactForm.invalid || this.isFormSubmitting) {
            return;
        }

        this.isFormSubmitting = true;
        this.serverError = null;

        this.contactservice.createContact(this.CreateContactForm.value).subscribe(
            contactDetails => {

                this.router.navigate(['/contact-details', { id: contactDetails.contactId }]);
            },
            (error: HttpErrorResponse) => {
                if (error.status === 400) {
                    this.serverError = error.error;
                } else if (error.status === 401) {
                    this.serverError = 'We are currently unable to process your request. Please try again later.';
                } else {
                    this.serverError = 'Oops, we are having a problem. Please try again later.';
                }
            },
        );
    }

}
