import { Component, OnInit } from '@angular/core';
import {Contact} from 'src/app/models/contact';
import { ContactService } from 'src/app/service/contact.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
    selector: 'ec-landing-page',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css'],
})
export class LandingPageComponent implements OnInit{

   contactList: Contact[];
   noresult = false;
serverError: string;
constructor(
     private contactservice: ContactService,
     private router: Router

 )
 {}
ngOnInit(){
debugger;
this.contactservice.getAllContacts().subscribe(
        contactDetails => {
            console.log(contactDetails);
            if (contactDetails.length > 0)
{
            this.contactList = contactDetails;
}
else
{
    console.log(contactDetails);
    this.noresult = true;

}
        },
        (error: HttpErrorResponse) => {
            if (error.status === 400) {
                this.serverError = error.error;
            } else if (error.status === 401) {
                this.serverError = 'We are currently unable to process your request. Please try again later.';
            } else {
                this.serverError = 'Oops, we are having a problem. Please try again later.';
            }
        },
    );
}

}
