import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainNavComponent } from './components/layout/main-nav.component';
import { LandingPageComponent } from './components/routes/home/home.component';
import {HttpClientModule} from '@angular/common/http';
import { CreateContactComponent } from './components/routes/create-contact/create.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule , FormBuilder} from '@angular/forms';
import { ContactDetailsComponent } from './components/routes/contact-details/contact-details.component';


@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    LandingPageComponent,
    CreateContactComponent,
    ContactDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [FormBuilder],
  bootstrap: [AppComponent]
})
export class AppModule { }
