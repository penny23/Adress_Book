export interface Contact
{
  contactId: number;
  firstName: string;
  surName: string;
  contactNumber: string;
  birthDate: Date;

}
