export interface ContactType{
     contactTypeId: number;
description: string;

}
