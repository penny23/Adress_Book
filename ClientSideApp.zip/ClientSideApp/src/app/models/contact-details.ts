export interface ContactDetail{

contactDetailsId: number;
dscription: string;
contactId: number;
contactTypeId: number;
}
